# SakevaNews - Новостной сайт игроков сервера Sakeva

![SakevaNews Banner](https://img.shields.io/badge/SakevaNews-v1.0.0-FF6B9D?style=for-the-badge)
![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white)
![React](https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=react&logoColor=black)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=node.js&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-003B57?style=for-the-badge&logo=sqlite&logoColor=white)

## 📋 Описание

SakevaNews - это полнофункциональный веб-сайт для публикации новостей от игроков сервера Sakeva. Проект включает систему аутентификации, модерацию контента и административную панель с тремя уровнями доступа.

**База данных**: MySQL (или автоматически SQLite если MySQL не настроен - локальный файл БД)

## ✨ Основные возможности

### 🔐 Система ролей (3 уровня)
- **user** - обычные игроки (создание новостей на модерацию)
- **admin** - модераторы (одобрение/отклонение новостей)
- **owner** - владелец сайта (полный доступ + управление админами)

### 📰 Функционал новостей
- Просмотр одобренных новостей
- Поиск по заголовку
- Пагинация
- Создание новостей с изображениями
- Модерация контента

### 👥 Административная панель
- Модерация новостей (одобрение/отклонение/удаление)
- Управление пользователями (только для owner)
- Изменение ролей пользователей
- Блокировка/разблокировка аккаунтов
- Статистика сайта

### 🎨 Дизайн
- Розово-белый градиент (#FF6B9D → #FFFFFF)
- Шрифт Open Sans
- Framer Motion анимации
- Адаптивный дизайн (Tailwind CSS)

## 🛠 Технологический стек

### Backend
- NySQL / SQLite (автоматический выбор)
- Sequelize ORM
- TypeScript
- MongoDB + Mongoose
- JWT аутентификация
- Bcrypt для хэширования паролей
- Rate limiting

### Frontend
- React 18
- TypeScript
- Vite
- TanStack Query (React Query)
- React Router DOM
- React Hook Form + Zod
- Tailwind CSS
- Framer Motion
- React Hot Toast
- React Icons

## 🚀 Установка и запуск
ySQL 8.0+ (опционально - если не указан, будет использован SQLite)
### Предварительные требования
- Node.js 18+ 
- MongoDB 7.0+
- npm или yarn

### 1. Клонирование репозитория
```bash
git clone <repository-url>
cd News
```

### 2. Настройка Backend

```bash
cd backend
npm install
```

Создайте файл `.env` на основе `.env.example`:
```bash
cp .env.example .env
```
# Для MySQL (оставьте пустым DB_TYPE или DB_HOST для автоматического использования SQLite)
DB_TYPE=mysql
DB_HOST=localhost
DB_PORT=3306
DB_NAME=sakevanews
DB_USER=root
DB_PASSWORD=

# Или оставьте закомментированным для SQLite (локальный файл)
# DB_TYPE=
# DB_HOST=

JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRES_IN=7d
PORT=5000
NODE_ENV=development
FRONTEND_URL=http://localhost:5173
```Mexa`
- **Пароль:** `GL2200Gl!@`

Выход команды:
```
✅ Connected to database
✅ Database tables synchronized
🎉 Owner account created successfully!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Nick:     Mexa
   Password: GL2200Gl!@ner аккаунта**

```bash
npm run init-db
```

Этот скрипт создаст первого пользователя с ролью **owner**:
- **Ник:** `sakeva_owner`
- **Пароль:** `sakeva2025`

Выход команды:
```
✅ Connected to MongoDB
🎉 Owner account created successfully!
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Nick:     sakeva_owner
   Password: sakeva2025
   Role:     owner
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  Please change the password after first login!
```

### 4. Запуск Backend

```bash
npm run dev
```

Backend запустится на `http://localhost:5000`

### 5. Настройка Frontend

```bash
cd .� База данных

Проект поддерживает два варианта БД:

### MySQL (рекомендуется для продакшена)
1. Установите MySQL 8.0+
2. Создайте базу данных: `CREATE DATABASE sakevanews;`
3. Укажите параметры в `.env` (см. выше)

### SQLite (автоматически для локальной разработки)
Если MySQL не настроен - проект автоматически создаст локальную SQLite БД в файле `backend/data/sakevanews.sqlite`. Никаких дополнительных действий не требуется!

Frontend запустится на `http://localhost:5173`

## 🐳 Запуск с Docker Compose

```bash
# Из корневой директории проекта
docker-compose up -d

# Инициализация БД (после запуска контейнеров)
docker exec -it sakevanews-backend npm run init-db
```ySQL/SQLite (автовыбор)

Сервисы будут доступны:
- Frontend: http://localhost:5173
- Backend API: http://localhost:5000
- MongoDB: localhost:27017

## 📁 Структура проекта

```
News/
├── backend/
│   ├── src/
│   │   ├── config/
│   │   │   └── database.ts       # Подключение к MongoDB
│   │   ├── models/
│   │   │   ├── User.ts           # Модель пользователя
│   │   │   └── News.ts           # Модель новости
│   │   ├── middleware/
│   │   │   └── auth.ts           # JWT аутентификация
│   │   ├── routes/
│   │   │   ├── auth.ts           # Роуты авторизации
│   │   │   ├── news.ts           # Роуты новостей
│   │   │   └── users.ts          # Роуты пользователей
│   │   └── server.ts             # Главный файл сервера
│   ├── scripts/
│   │   └── init-db.ts            # Скрипт инициализации БД
│   ├── package.json
│   ├── tsconfig.json
│   └── .env.example
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── Navbar.tsx        # Навигационная панель
│   │   │   ├── NewsCard.tsx      # Карточка новости
│   │   │   └── ProtectedRoute.tsx # Защищенный роут
│   │   ├── contexts/
│   │   │   └── AuthContext.tsx   # Контекст аутентификации
│   │   ├── pages/
│   │   │   ├── HomePage.tsx      # Главная страница
│   │   │   ├── LoginPage.tsx     # Страница входа
│   │   │   ├── RegisterPage.tsx  # Страница регистрации
│   │   │   ├── CreateNewsPage.tsx # Создание новости
│   │   │   └── AdminPage.tsx     # Админ панель
│   │   ├── lib/
│   │   │   └── api.ts            # Axios конфигурация
│   │   ├── types/
│   │   │   └── index.ts          # TypeScript типы
│   │   ├── App.tsx               # Главный компонент
│   │   ├── main.tsx              # Точка входа
│   │   └── index.css             # Глобальные стили
│   ├── package.json
│   ├── vite.config.ts
│   ├── tailwind.config.js
│   └── .env.example
│
├── docker-compose.yml
└── README.md
```

## 🔑 API Эндпоинты

### Аутентификация
- `POST /api/auth/register` - Регистрация
- `POST /api/auth/login` - Вход
- `GET /api/auth/me` - Получить текущего пользователя

### Новости
- `GET /api/news` - Получить одобренные новости (публичный)
- `POST /api/news` - Создать новость (требует аутентификации)
- `GET /api/news/pending` - Новости на модерацию (admin/owner)
- `PATCH /api/news/:id/approve` - Одобрить новость (admin/owner)
   - **Ник:** `Mexa`
   - **Пароль:** `GL2200Gl!@`алить новость (admin/owner)

### Пользователи
- `GET /api/users` - Список пользователей (только owner)
- `PATCH /api/users/:id/role` - Изменить роль (только owner)
- `PATCH /api/users/:id/block` - Блокировка/разблокировка (только owner)
- `GET /api/users/stats` - Статистика (admin/owner)

## 👤 Первый вход

1. ОткройтеMexa` защищен от удаления/изменения роли
- Автоматический выбор БД (MySQL/SQLite)
2. Нажмите "Вход"
3. Введите учетные данные owner:
   - **Ник:** `sakeva_owner`
   - **Пароль:** `sakeva2025`
4. После входа вы получите полный доступ к административной панели

## 🔒 Безопасность

- Пароли хэшируются с помощью bcrypt
- JWT токены для аутентификации
- Rate limiting на API
- CORS настроен
- Валидация на клиенте и сервере
- Аккаунт `sakeva_owner` защищен от удаления/изменения роли

## 📝 Дополнительные заметки

### Иерархия ролей
- `user` < `admin` < `owner`
- Роли определяют доступ к функциям
- Owner не может быть понижен до admin или заблокирован

### Модерация новостей
- Все новости после создания имеют статус `pending`
- Админы и owner могут одобрить/отклонить/удалить
- Только одобренные новости видны на главной странице

### Управление пользователями (только owner)
- Изменение ролей: user ↔ admin
- Нельзя создать нового owner через интерфейс
- Блокировка запрещает вход в систему

## 🤝 Вклад в проект

1. Fork проекта
2. Создайте ветку (`git checkout -b feature/AmazingFeature`)
3. Commit изменений (`git commit -m 'Add some AmazingFeature'`)
4. Push в ветку (`git push origin feature/AmazingFeature`)
5. Откройте Pull Request

## 📄 Лицензия

MIT License

## 👨‍💻 Автор

Sakeva Team

---

**🎮 Создано для сообщества игроков сервера Sakeva с любовью ❤️**
